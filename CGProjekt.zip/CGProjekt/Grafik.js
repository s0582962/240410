import { OrbitControls } from 'https://cdn.jsdelivr.net/npm/three@0.125.2/examples/jsm/controls/OrbitControls.js';

//----G L O B A L E   V A R I A B L E N---globale variablen-----------------------------------------------------------------
    //Spielfiguren  & und ihre eigene Beleuchtung
    let mesh, meshRed, meshGreen, meshBlue, meshYellow; 
    const pointLightRed = new THREE.PointLight(0xff0000, 2.5, 120); //color, intensity, distance
    const pointLightGreen = new THREE.PointLight(0x00ff00, 2.5, 120);
    const pointLightBlue = new THREE.PointLight(0x0000ff, 2.5, 120);
    const pointLightYellow = new THREE.PointLight(0xffff00, 2.5, 120);
    //Würfelcounter für jede Spielfigur
    var countR,countG,countB,countY;      
    //Index der Koordinate jeder Spielfigur
    var currentIndex, currentIndexR,currentIndexG,currentIndexB,currentIndexY; 
    //SPIELFELD KOORDINATEN
    let home; 
    const homeRed = [
    [0, -0.5, -7.5], //0
    [0, -0.5, -6],
    [0,-0.5,-4.5],
    [0,-0.5,-3],
    
    [0,-0.5,-1.5] //4 
    ];
    const homeGreen = [  
    [-7.5,-0.5,0],
    [-6,-0.5,0],
    [-4.5,-0.5,0],
    [-3,-0.5,0],

    [-1.5,-0.5,0]
    ];
    const homeBlue = [
    [0, -0.5, 7.5], //0
    [0, -0.5, 6],
    [0,-0.5,4.5],
    [0,-0.5,3],
    
    [0,-0.5,1.5] //4 
    ];
    const homeYellow = [  
    [7.5,-0.5,0],
    [6,-0.5,0],
    [4.5,-0.5,0],
    [3,-0.5,0],
    
    [1.5,-0.5,0]
    ];
    const mainPath = [
    [-1.5, -0.5, -7.5], //0
    [-1.5, -0.5, -6],
    [-1.5,-0.5,-4.5],
    [-1.5,-0.5,-3],
    
    //[-1.5,-0.5,-1.5] 
    
    [-3,-0.5,-1.5], //4
    [-4.5,-0.5,-1.5],
    [-6,-0.5,-1.5],
    [-7.5,-0.5,-1.5],

    [-9,-0.5,-1.5], //8
    [-9,-0.5,0],    
    [-9,-0.5,1.5],

    [-7.5,-0.5,1.5], //11
    [-6,-0.5,1.5],
    [-4.5,-0.5,1.5],
    [-3,-0.5,1.5],
    
    //[-1.5,-0.5,1.5],

    [-1.5,-0.5,3], //15
    [-1.5,-0.5,4.5],
    [-1.5,-0.5,6],
    [-1.5,-0.5,7.5],

    [-1.5,-0.5,9], //19
    [0,-0.5,9],
    [1.5,-0.5,9],

    [1.5,-0.5,7.5], //22
    [1.5,-0.5,6],
    [1.5,-0.5,4.5],
    [1.5,-0.5,3],

    //[1.5,-0.5,1.5]

    [3,-0.5,1.5], //26
    [4.5,-0.5,1.5],
    [6,-0.5,1.5],
    [7.5,-0.5,1.5],

    [9,-0.5,1.5], //30
    [9,-0.5,0],
    [9,-0.5,-1.5],

    [7.5,-0.5,-1.5], //33
    [6,-0.5,-1.5],
    [4.5,-0.5,-1.5],
    [3,-0.5,-1.5],

    //[-1.5,-0.5,-1.5],

    [1.5,-0.5,-3], //37
    [1.5,-0.5,-4.5],
    [1.5,-0.5,-6],
    [1.5,-0.5,-7.5],

    [1.5,-0.5,-9], //41
    [0,-0.5,-9],
    [-1.5,-0.5,-9] //43
    ];
  
    //Pop up wenn ein Spieler gewonnen hat
    let wintext, wintextColor;
//---Ausführung---------------------------------------------------------------------

main();

//---F U N K T I O N E N---funktionen------------------------------------------------------------------
/**
 * ---main()
 */
function main() {
// create context
    const canvas = document.querySelector("#c");
    const gl = new THREE.WebGLRenderer({
        canvas,
        antialias: true
    });

// create camera
    const angleOfView = 55;
    const aspectRatio = canvas.clientWidth / canvas.clientHeight;
    const nearPlane = 0.1;
    const farPlane = 100;
    const camera = new THREE.PerspectiveCamera(
        angleOfView,
        aspectRatio,
        nearPlane,
        farPlane
    );
    camera.position.set(0, -22, 0);

// create the scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0.3, 0.5, 0.8);
    const fog = new THREE.Fog("grey", 5,80); //color, distance, far-distance
    scene.fog = fog;
    //var grid = new THREE.GridHelper(100, 10); //add grid
    //scene.add(grid);

// Create the upright plane
    const planeWidth = 20;
    const planeHeight =  20;
    const planeGeometry = new THREE.PlaneGeometry(
        planeWidth,
        planeHeight
    );

// create MATERIALS
    //material des Spielfelds
    //'textures/make-your-ludo-board.png' Quelle: https://images.saymedia-content.com/.image/c_limit%2Ccs_srgb%2Cq_auto:eco%2Cw_700/MTc2Mjk3MTYwNTkyMjcwNTA5/make-your-ludo-board.webp
    const textureLoader = new THREE.TextureLoader();
    const planeTextureMap = textureLoader.load('textures/make-your-ludo-board.png'); 
    planeTextureMap.wrapS = THREE.RepeatWrapping;
    planeTextureMap.wrapT = THREE.RepeatWrapping;
    planeTextureMap.repeat.set(1, 1);
    planeTextureMap.magFilter = THREE.NearestFilter;
    planeTextureMap.minFilter = THREE.NearestFilter;
    planeTextureMap.anisotropy = gl.getMaxAnisotropy();
    const planeMaterial = new THREE.MeshStandardMaterial({
        map: planeTextureMap,
        side: THREE.DoubleSide,
    });

    //material des Holz-Hintergrunds des Spielfeldes 
    //'textures/wood.jpg' Quelle: https://media.istockphoto.com/id/1083302826/de/foto/laminat-holz-boden-textur-hintergrund.jpg?s=1024x1024&w=is&k=20&c=jmrQNHTFuLkxZhIOE3YXlGY49r4HGRcMRNqOuVcRGlw=
    const bgplaneTextureMap = textureLoader.load('textures/wood.jpg'); 
    bgplaneTextureMap.wrapS = THREE.RepeatWrapping;
    bgplaneTextureMap.wrapT = THREE.RepeatWrapping;
    bgplaneTextureMap.repeat.set(1, 1);
    bgplaneTextureMap.magFilter = THREE.NearestFilter;
    bgplaneTextureMap.minFilter = THREE.NearestFilter;
    bgplaneTextureMap.anisotropy = gl.getMaxAnisotropy();
    const bgplaneMaterial = new THREE.MeshStandardMaterial({
        map: bgplaneTextureMap,
        side: THREE.DoubleSide,
    });

// ceate MESHES
    //mesh des Spielfelds
    const plane = new THREE.Mesh(planeGeometry, planeMaterial);
    plane.rotation.x = Math.PI /2;
    scene.add(plane);
    //mesh des Holz-Hintergrunds des Spielfeldes 
    const bgplane = new THREE.Mesh(planeGeometry, bgplaneMaterial);
    bgplane.rotation.x = Math.PI /2;
    bgplane.position.y = +0.01; // Slightly offset to avoid z-fighting
    scene.add(bgplane); 

    //mesh der SPIELFIGUREN (Quader)
    const boxGeom = new THREE.BoxGeometry(1, 1, 1, 5, 5, 5);
    meshRed = new THREE.Mesh(
        boxGeom,
        new THREE.MeshBasicMaterial({ color: 0xff0000 }) // Red
    );   
    scene.add(meshRed);
    meshGreen = new THREE.Mesh(
        boxGeom,
        new THREE.MeshBasicMaterial({ color: 0x00ff00 }) // Green
    );
    scene.add(meshGreen);
    meshBlue = new THREE.Mesh(
        boxGeom,
        new THREE.MeshBasicMaterial({ color: 0x0000ff }) // Blue
    );
    scene.add(meshBlue);
    meshYellow = new THREE.Mesh(
        boxGeom,
        new THREE.MeshBasicMaterial({ color: 0xffff00 }) // Yellow
    );
    scene.add(meshYellow);

// create ORBITCONTROLS (für Pfeiltastensteuerung)
    const orbitcontrols = new OrbitControls(camera, canvas);
    orbitcontrols.enableDamping = true;

// create LIGHTS
    const color = 0xffffff;
    const intensity = 0.7;
    const light = new THREE.DirectionalLight(color, intensity);
    light.target = plane;
    light.position.set(0, 30, 30);
    scene.add(light);
    scene.add(light.target);

    const ambientColor = 0xffffff;
    const ambientIntensity = 0.4;
    const ambientLight = new THREE.AmbientLight(ambientColor, ambientIntensity);
    scene.add(ambientLight);

    //pointlights hinzufügen (sind immer bei den Spielfiguren)
    scene.add(pointLightRed);
    scene.add(pointLightGreen);
    scene.add(pointLightBlue);
    scene.add(pointLightYellow);

// trackballcontrolls und clock  // attach them here, since appendChild needs to be called first
    var trackballControls = initTrackballControls(camera, gl);
    var clock = new THREE.Clock();

// DRAW FUNCTION
    function draw(time){
        time *= 0.001;
        trackballControls.update(clock.getDelta());
        if (resizeGLToDisplaySize(gl)) {
            const canvas = gl.domElement;
            camera.aspect = canvas.clientWidth / canvas.clientHeight;
            camera.updateProjectionMatrix();
        }
        light.position.x = 20*Math.cos;//(time);
        light.position.y = 20*Math.sin;//(time);
        gl.render(scene, camera);
        
        //Pfeiltastensteuerung
        orbitcontrols.update(); 

        //Pointlights der Spielfiguren
        pointLightRed.position.set(meshRed.position.x,meshRed.position.y,meshRed.position.z);
        pointLightGreen.position.set(meshGreen.position.x,meshGreen.position.y,meshGreen.position.z);
        pointLightBlue.position.set(meshBlue.position.x,meshBlue.position.y,meshBlue.position.z);
        pointLightYellow.position.set(meshYellow.position.x,meshYellow.position.y,meshYellow.position.z);
        
        requestAnimationFrame(draw);
    }
    
// Reset Game Aufruf vor dem Start und Loader
    resetGame();
    var loader = new THREE.OBJLoader();
    requestAnimationFrame(draw);
}
/**
 *  UPDATE RESIZE
 */
function resizeGLToDisplaySize(gl) {
    const canvas = gl.domElement;
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    const needResize = canvas.width != width || canvas.height != height;
    if (needResize) {
        gl.setSize(width, height, false);
    }
    return needResize;
}
//-----------------------------------------------------------------....---------------------------
//---W Ü R F E L S P I E L---fürs würfelspiel relevante Funktionen--------------------------------
/**
 * throwDice  Würfelwurf. Wird bei den 4 Buttons ausgeführt 
 * @param {*} playerStartingIndex //Ist der Index der ersten Koordinate jeder Spielfigur beim Spielbeginn. 
 */
function throwDice(playerStartingIndex) {

//Voreinstellung. Entscheidung welcher Spieler würfelt. 0=rot, 11=grün, 22=blau, 33=gelb.
    switch (playerStartingIndex) {
        case 0:
            wintext="ROT ist im Ziel!"
            wintextColor ='red';
            currentIndex = currentIndexR;
            mesh = meshRed;
            home = homeRed;
            break;
        case 11:
            wintext="GRÜN ist im Ziel!"
            wintextColor ='green';
            currentIndex = currentIndexG;
            mesh = meshGreen;
            home = homeGreen;
            break;
        case 22:
            wintext="BLAU ist im Ziel!"
            wintextColor ='blue';
            currentIndex = currentIndexB;
            mesh = meshBlue;
            home = homeBlue;
            break;
        case 33:
            wintext="GELB ist im Ziel!"
            wintextColor ='yellow';
            currentIndex = currentIndexY;
            mesh = meshYellow;
            home = homeYellow;
            break;
        default:
            console.log("Falsche eingabe: " + playerStartingIndex); // Invalid playerStartingIndex
    }

    updateCounter(1,playerStartingIndex);
    
    let dice = Math.floor(Math.random() * 6) + 1;
    console.log("randomly generated = " + dice);
//Überprüfe ob Würfelwurf übers Ziel hinnausschießt. 
//Wenn nicht:
    if (currentIndex + dice < mainPath.length + home.length + playerStartingIndex) {
        for (let i = 0; i < dice; i++) {
            setTimeout(function () {
        //Ein Sprung auf dem Spielfeld, wird wiederholt für jede Iteration der Schleife.
                hop(); 
            }, i * 300); // Wait for i seconds
        }
    } 
//Falls Würfelwurf übers Ziel hinnausschießt: 
    else {
        console.log(dice + ' is too big');
    }

    /**
     * Ein Sprung auf dem Spielfeld
     */
    function hop(){
        currentIndex += 1;

    //Berechne die Position der Spielfigur
        let actualPosition = currentIndex % mainPath.length;
    //Überprüfe ob Position auf dem mainPath liegt
    //Wenn ja:
        if (currentIndex < mainPath.length + playerStartingIndex) {
        // On the main path
            mesh.position.x = mainPath[actualPosition][0]; //Array[Koordinaten-Array][x-Koordinate]
            mesh.position.z = mainPath[actualPosition][2]; //Array[Koordinaten-Array][Z-Koordinate]
        } 
    //Falls Nein:
    //Überprüfe ob Position auf dem homePath liegt
    //Wenn ja:
        else if (currentIndex < mainPath.length + home.length + playerStartingIndex) {
        // On the home path
        //Berechne die Position der Spielfigur wenn sie sich im homePath befinden würde (home ist zb der homeRed Array)
            let homeIndex = currentIndex - mainPath.length - playerStartingIndex;
            mesh.position.x = home[homeIndex][0]; //Array[Koordinaten-Array][x-Koordinate]
            mesh.position.z = home[homeIndex][2]; //Array[Koordinaten-Array][Z-Koordinate]
        //Überprüfe ob Win Condition erfüllt wurde (Ziel erreicht)
        //Wenn ja:
            if (homeIndex === home.length - 1) {
                console.log(wintext+" You Won!");
                showWinnerLabel(wintext, wintextColor);
            }
        } 
    //Falls weder auf dem mainPath noch dem homePath:
        else {
        //zurücksetzen des Index, da Sprung nicht möglich
            currentIndex -= 1; 
        }
    //Zurücksetzen der Hilfsvariable
        setIndexVariable(playerStartingIndex, currentIndex); 
    }
}
/**
 * Würfelcounter eines Spielers um 1 erhöhen
 * @param {*} i  //Zahl um die erhöht werden soll (eig immer 1)
 * @param {*} playerStartingIndex 
 */
function updateCounter(i,playerStartingIndex){
    switch (playerStartingIndex) {
        case 0:
            countR+=i;
            const countlabel = document.getElementById('countlabel');
            countlabel.textContent = countR;
            break;
        case 11:
            countG+=i;
            const countlabelG = document.getElementById('countlabelG');
            countlabelG.textContent = countG;
            break;
        case 22:
            countB+=i;
            const countlabelB = document.getElementById('countlabelB');
            countlabelB.textContent = countB;
            break;
        case 33:
            countY+=i;
            const countlabelY = document.getElementById('countlabelY');
            countlabelY.textContent = countY;
            break;
        default:
            console.log("Falsche eingabe: " + playerStartingIndex); // Invalid playerStartingIndex
    }
}
/**
 * Winner Text, wenn ein Spieler das Ziel erreicht hat
 * Verwendet in: throwDice -> hop
 * @param {*} wintext 
 * @param {*} color 
 */
function showWinnerLabel(wintext, color) {
    const winLabel = document.getElementById('winnerLabel');
    winLabel.textContent = wintext;
    document.getElementById('winnerLabel').style.color = color;
    document.getElementById('winnerLabel').style.display = 'flex';
    setTimeout(function () {
        document.getElementById('winnerLabel').style.display = 'none'; // Hide the winner label
    }, 1 * 1000); // Wait for i seconds
}
/**
 * Zurücksetzen der Hilfsvariable
 * Verwendet in: throwDice -> hop
 * @param {*} playerStartingIndex 
 * @param {*} currentIndex 
 */
function setIndexVariable(playerStartingIndex, currentIndex) {
//0=rot, 11=grün, 22=blau, 33=gelb.
    switch (playerStartingIndex) {
        case 0:
            currentIndexR = currentIndex;
            break;
        case 11:
            currentIndexG = currentIndex;
            break;
        case 22:
            currentIndexB = currentIndex;
            break;
        case 33:
            currentIndexY = currentIndex;
            break;
    }
}
//Eventlistener für Würfelwurfe
document.getElementById('throwDice').addEventListener('click', function() {
    throwDice(0);
});
document.getElementById('throwDiceG').addEventListener('click', function() {
    throwDice(11);
});
document.getElementById('throwDiceB').addEventListener('click', function() {
    throwDice(22);
});
document.getElementById('throwDiceY').addEventListener('click', function() {
    throwDice(33);
});


//-------------------------------------------------------------------------------------------------
//---MOVE FUNCTIONS----(zur Nutzung der Orbitscontrolls, nicht für das Würfelspiel relevant)-------
var increment =1.5;
function moveUp(){
    meshRed.position.z +=increment;
    meshGreen.position.z +=increment;
    meshBlue.position.z +=increment;
    meshYellow.position.z +=increment;
    currentIndex+=1;
    getPosition();
}
function moveDown(){
    meshRed.position.z -= increment;
    meshGreen.position.z -=increment;
    meshBlue.position.z -=increment;
    meshYellow.position.z -=increment;
    currentIndex+=1;
    getPosition();
}
function moveRight(){
    meshRed.position.x +=increment;
    meshGreen.position.x +=increment;
    meshBlue.position.x +=increment;
    meshYellow.position.x +=increment;
    currentIndex+=1;
    getPosition();
}
function moveLeft(){
    meshRed.position.x -= increment;
    meshGreen.position.x -=increment;
    meshBlue.position.x -=increment;
    meshYellow.position.x -=increment;
    currentIndex+=1;
    getPosition();
}
/*
// Eventlistener für Move-Buttons
document.getElementById('moveUp').addEventListener('click', moveUp);
document.getElementById('moveDown').addEventListener('click', moveDown);
document.getElementById('moveRight').addEventListener('click', moveRight);
document.getElementById('moveLeft').addEventListener('click', moveLeft);
*/
function getPosition(){ //legacy Feature
    meshRed.geometry.computeBoundingBox();
    var boundingBox = meshRed.geometry.boundingBox;

    var position = new THREE.Vector3();
    position.subVectors( boundingBox.max, boundingBox.min );
    position.multiplyScalar( 0.5 );
    position.add( boundingBox.min );
    
    position.applyMatrix4( meshRed.matrixWorld );
    console.log('car: '+currentIndex+' ['+position.x + ',' + position.y + ',' + position.z+'],');
    return position;
}
document.addEventListener('keydown', function(event) {
    switch (event.key) {
        case 'ArrowUp':
            moveUp();
            break;
        case 'ArrowDown':
            moveDown();
            break;
        case 'ArrowLeft':
            moveLeft();
            break;
        case 'ArrowRight':
            moveRight();
            break;
        case ' ':
            throwDice(0);
            break;
        case 'r':
            resetGame();
            break;
        default:
            break;
    }
});

//----------------------------------------------------------------------------------------
//---START OR RESET THE GAME--------------------------------------------------------------
/**
 * wird verwendet in: Buttons, main()
 */
function resetGame(){
    document.getElementById('winnerLabel').style.display = 'none'; // Hide the winner label

    console.log(mainPath[0][0],mainPath[0][1],mainPath[0][2]);
    meshRed.position.set(mainPath[0][0],mainPath[0][1],mainPath[0][2]);
    meshGreen.position.set(mainPath[11][0],mainPath[11][1],mainPath[11][2]);
    meshBlue.position.set(mainPath[22][0],mainPath[22][1],mainPath[22][2]);
    meshYellow.position.set(mainPath[33][0],mainPath[33][1],mainPath[33][2]);

    countR=0;
    countG=0;
    countB=0;
    countY=0;

    currentIndex=0;
    currentIndexR=0;
    currentIndexG=11;
    currentIndexB=22;
    currentIndexY=33;

    updateCounter(0,0);
    updateCounter(0,11);
    updateCounter(0,22);
    updateCounter(0,33);
}
document.getElementById('reset').addEventListener('click', resetGame);


