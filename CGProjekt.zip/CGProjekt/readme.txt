Führen Sie index.html mit Live Server aus.

Die Steuerung besteht aus den Buttons auf dem Screen (für's Würfelspiel) und den Pfeiltasten (free-roam modus). Beide Steuerungsarten haben keinen Effekt auf die andere.
Der Reset-Button setzt alle Spieler und deren Counter zurück.
Die gewürfelten Zahlen sind nur auf der Konsolenausgabe zu sehen.
Die Konsole zeigt auch an, wenn ein Spieler zu groß gewürfelt hat. 
Bei Kollision passiert nichts, und jede Farbe hat nur einen Spieler.


Die Demo-Videos habe ich mit der Handykamera gefilmt, weil Zuhause wegen Bauarbeiten nichts ging, und die Uni-Rechner mit VSCode nicht über keine App für Screen-Aufnahmen verfügten (Win+G hat nicht funktioniert). 




Dokumentation (Zusammenfassung der Funktionen):

main()

Initialisiert das Spielfeld, die Kamera, die Szene, das Licht, die Spielfiguren und die OrbitControls.
	Ruft resetGame() und den draw-Loop auf.

resizeGLToDisplaySize(gl)
	Passt die Größe des Canvas an, falls nötig.

throwDice(playerStartingIndex)
	Würfelt und bewegt die Spielfigur entsprechend der gewürfelten Zahl.
	Ruft updateCounter(), hop(), und showWinnerLabel() auf.
	PlayerStartingIndex ist der Index des Feldes im "mainPath"-Arrays, auf dem die Spieler starten. 0=rot, 11=grün, 22=blau, 33=gelb.  

hop()
	Bewegt die Spielfigur um eine Position weiter.
	Überprüft dabei, ob die Spielfigur auf dem Hauptpfad (weiße Felder) oder dem Heimatpfad (Spielerfarbe) ist.
	Setzt den aktuellen Index zurück, wenn das Ziel erreicht ist.

updateCounter(i, playerStartingIndex)
	Aktualisiert den Würfelcounter für den entsprechenden Spieler.

showWinnerLabel(wintext, color)
	Zeigt den Gewinnertext an, wenn eine Spielfigur das Ziel erreicht.

setIndexVariable(playerStartingIndex, currentIndex)
	Setzt die aktuelle Indexvariable für den entsprechenden Spieler.

moveUp()
	Bewegt alle Spielfiguren nach oben.

moveDown()
	Bewegt alle Spielfiguren nach unten.

moveLeft()
	Bewegt alle Spielfiguren nach links.

moveRight()
	Bewegt alle Spielfiguren nach rechts.

resetGame()
	Setzt das Spiel zurück und initialisiert die Positionen und Indizes der Spielfiguren.


Eventlistener für die Würfeln-Buttons:

document.getElementById('throwDice').addEventListener('click', function() { throwDice(0); });
	Spieler ROT würfelt.

document.getElementById('throwDiceG').addEventListener('click', function() { throwDice(11); });
	Spieler GRÜN würfelt.

document.getElementById('throwDiceB').addEventListener('click', function() { throwDice(22); });
	Spieler BLAU würfelt.

document.getElementById('throwDiceY').addEventListener('click', function() { throwDice(33); });
	Spieler GELB würfelt.

document.getElementById('reset').addEventListener('click', resetGame);
	resetGame() -> Setzt das Spiel zurück und initialisiert die Positionen und Indizes der Spielfiguren.